
# L3 Web Project

This project is a web application that allows you to check cocktails recipes.
You can create an account and add your own recipes into your favorites.


## Authors

- [@KevinKGE](https://github.com/kevinKGE)
- [@YannickMerleau](https://github.com/YannickMerleau)
- [@RomainVigreux](https://github.com/RomainVigreux)
