<footer>
    <div class="container">
        <div class="row">
            <div class="col mt-4">
                <em><small>Projet Web 2022 - L3 Informatique - Kevin Gerber, Yannick Merleau, Romain Vigreux</small></em>
            </div>
        </div>
    </div>

</footer>
</body>
</html>