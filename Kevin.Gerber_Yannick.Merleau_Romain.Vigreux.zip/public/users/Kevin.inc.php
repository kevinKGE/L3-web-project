<?php $user =array (
  'login' => 'Kevin',
  'password' => 'ffb4761cba839470133bee36aeb139f58d7dbaa9',
  'name' => 'Gerber',
  'firstName' => 'Kevin',
  'sex' => 'male',
  'birthDate' => '',
)?>