<?php $user =array (
  'login' => 'yannick',
  'password' => '76fbeec969ca5e8c53c03baa1a8cd03f1007b16f',
  'name' => '',
  'firstName' => '',
  'sex' => 'male',
  'birthDate' => '',
)?>