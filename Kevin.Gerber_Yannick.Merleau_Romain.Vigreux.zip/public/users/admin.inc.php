<?php $user =array (
  'login' => 'admin',
  'password' => 'd033e22ae348aeb5660fc2140aec35850c4da997',
  'name' => 'John',
  'firstName' => 'Doe',
  'sex' => 'male',
  'birthDate' => '',
)?>